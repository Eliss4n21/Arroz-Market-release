# 🌾 ArrozMarket

Plataforma de análises diárias do mercado orizícola brasileiro.  
Stack: **Node.js + Express + Puppeteer** (backend) · **HTML/CSS/JS puro** (frontend)

---

## 📁 Estrutura de Pastas

```
arrozmarket/
├── src/
│   ├── server.js      ← Servidor Express (ponto de entrada)
│   ├── db.js          ← Banco de dados em arquivo JSON
│   └── scraper.js     ← Puppeteer: coleta cotações do CEPEA
├── routes/
│   └── api.js         ← Todas as rotas REST (/api/...)
├── middleware/
│   └── auth.js        ← Verificação de token JWT
├── public/
│   ├── index.html     ← Site principal (frontend)
│   └── admin.html     ← Painel administrativo
├── data/              ← Criado automaticamente (banco local)
│   └── db.json        ← Dados persistidos (não sobe no Git)
├── .env.example       ← Modelo de variáveis de ambiente
├── .gitignore
├── package.json
└── README.md
```

---

## 🚀 Rodar Localmente (primeira vez)

### 1. Pré-requisitos
- [Node.js 18+](https://nodejs.org) instalado
- [Git](https://git-scm.com) instalado

### 2. Clonar e instalar
```bash
git clone https://github.com/SEU_USUARIO/arrozmarket.git
cd arrozmarket
npm install
```

### 3. Configurar variáveis de ambiente
```bash
# Copia o modelo
cp .env.example .env

# Abre o .env e edita:
# JWT_SECRET → gere uma string aleatória com:
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

Seu `.env` ficará assim:
```env
PORT=3000
JWT_SECRET=cole_aqui_a_string_gerada_acima
JWT_EXPIRES=7d
CEPEA_URL=https://www.cepea.esalq.usp.br/br/indicador/arroz.aspx
SCRAPE_INTERVAL_MIN=30
NODE_ENV=development
```

### 4. Iniciar
```bash
npm run dev       # desenvolvimento (reinicia ao salvar)
# ou
npm start         # produção
```

Acesse: **http://localhost:3000**  
Admin:  **http://localhost:3000/admin.html**  
Login admin: `fabio@arrozmarket.com.br` / `admin123`

---

## ☁️ Deploy no Railway (GitHub)

### Passo 1 — Subir no GitHub
```bash
git init
git add .
git commit -m "primeiro commit"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/arrozmarket.git
git push -u origin main
```

### Passo 2 — Criar projeto no Railway
1. Acesse [railway.app](https://railway.app) e faça login com GitHub
2. Clique em **"New Project"**
3. Selecione **"Deploy from GitHub repo"**
4. Escolha o repositório `arrozmarket`
5. Railway detecta Node.js automaticamente e inicia o build

### Passo 3 — Configurar variáveis de ambiente no Railway
No painel do Railway, clique no serviço → **Variables** → adicione:

| Variável               | Valor                                |
|------------------------|--------------------------------------|
| `JWT_SECRET`           | (string gerada com crypto acima)     |
| `JWT_EXPIRES`          | `7d`                                 |
| `CEPEA_URL`            | `https://www.cepea.esalq.usp.br/br/indicador/arroz.aspx` |
| `SCRAPE_INTERVAL_MIN`  | `30`                                 |
| `NODE_ENV`             | `production`                         |

> ⚠️ O Railway define `PORT` automaticamente. Não adicione PORT manualmente.

### Passo 4 — Domínio público
1. No Railway: **Settings → Networking → Generate Domain**
2. Seu site estará em: `https://arrozmarket-xxxx.up.railway.app`

### Passo 5 — Atualizar o site
```bash
git add .
git commit -m "atualização"
git push
```
O Railway faz deploy automático a cada push! 🎉

---

## 🔌 API REST — Referência

### Públicas (sem login)
```
GET  /api/cotacoes          → cotações atuais
GET  /api/videos            → vídeos publicados
POST /api/auth/login        → { email, senha } → { usuario, token }
POST /api/auth/registro     → { nome, email, senha } → { usuario, token }
```

### Autenticadas (header: `Authorization: Bearer TOKEN`)
```
GET  /api/me                → dados do usuário logado
PUT  /api/me                → { nome?, senhaAtual?, senhaNova? }
POST /api/videos/:id/curtir → dar/tirar curtida
GET  /api/videos/:id/curtida→ { curtido: true/false }
```

### Admin only
```
GET    /api/admin/videos          → todos os vídeos
POST   /api/admin/videos          → criar vídeo
PUT    /api/admin/videos/:id      → editar vídeo
DELETE /api/admin/videos/:id      → apagar vídeo
PUT    /api/admin/cotacoes        → { cotacoes: [...] }
GET    /api/admin/usuarios        → lista de usuários
PUT    /api/admin/usuarios/:id/role → { role: "admin"|"user" }
GET    /api/admin/config          → configurações do site
PUT    /api/admin/config          → salvar configurações
POST   /api/admin/scrape          → força coleta CEPEA agora
```

---

## 🔧 Sobre o Scraping CEPEA

O `scraper.js` funciona assim:

```
[Cron: a cada 30min]
      ↓
Puppeteer abre Chrome invisível
      ↓
Acessa site do CEPEA
      ↓
Lê tabela de preços
      ↓
Salva em db.json
      ↓
/api/cotacoes retorna os dados atualizados
```

**Enquanto a credencial CEPEA não estiver disponível**, o scraper usa **simulação com Float32Array** — todos os preços variam simultaneamente, simulando o comportamento real do mercado.

Para ativar o scraping real, basta obter acesso em [cepea.esalq.usp.br](https://www.cepea.esalq.usp.br) e configurar o seletor CSS correto no `src/scraper.js`.

---

## 👤 Usuário Admin padrão

| Campo  | Valor                         |
|--------|-------------------------------|
| E-mail | `fabio@arrozmarket.com.br`    |
| Senha  | `admin123`                    |
| Role   | `admin`                       |

> ⚠️ **Troque a senha após o primeiro acesso** em: Admin → Configurações → Alterar senha

---

## 🎨 Personalização de Cores

No site, clique no ícone de perfil → **Configurações** → escolha uma das 10 cores predefinidas ou use o seletor de cor personalizada.

---

## ❓ Problemas Comuns

**`Cannot find module 'puppeteer-core'`**  
→ Rode `npm install` novamente.

**Site abre mas API retorna erro**  
→ Verifique se o `.env` existe e se `JWT_SECRET` está preenchido.

**No Railway: build falha**  
→ Confirme que `package.json` está na raiz do repositório (não dentro de subpasta).

**Dados somem ao reiniciar no Railway**  
→ Normal — o Railway não persiste `/tmp`. Para persistência real, adicione um banco **PostgreSQL** pelo próprio painel do Railway (gratuito no plano Hobby) e adapte o `src/db.js`.
